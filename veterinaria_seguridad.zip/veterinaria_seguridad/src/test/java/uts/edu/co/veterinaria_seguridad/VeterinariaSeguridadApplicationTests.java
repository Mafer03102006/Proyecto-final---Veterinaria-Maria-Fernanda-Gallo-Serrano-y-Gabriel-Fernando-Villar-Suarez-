package uts.edu.co.veterinaria_seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeterinariaSeguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
